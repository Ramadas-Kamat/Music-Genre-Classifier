#!/bin/bash
echo Hi
cd /home/ramadas/Python/Source
python3 Main.py
